package com.example.netcommunication;

import android.app.Activity;
import android.os.Bundle;

/*装在测试工控机上*/
public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
