package com.rocktech.sharebookcase.opt;

/**
 * 
 * @author 618713 打印机指令集对象
 */
public interface IPrintOpt {

	public int getOptCode();
	
	public String toCpcl() ;

}
