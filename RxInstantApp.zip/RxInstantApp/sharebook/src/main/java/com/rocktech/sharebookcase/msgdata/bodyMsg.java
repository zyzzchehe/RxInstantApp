package com.rocktech.sharebookcase.msgdata;


public class bodyMsg {

    public  bizObject bizObject;

    public com.rocktech.sharebookcase.msgdata.bizObject getBizObject() {
        return bizObject;
    }

    public void setBizObject(com.rocktech.sharebookcase.msgdata.bizObject bizObject) {
        this.bizObject = bizObject;
    }
}
