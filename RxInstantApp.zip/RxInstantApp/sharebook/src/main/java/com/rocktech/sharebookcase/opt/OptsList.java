package com.rocktech.sharebookcase.opt;

import java.util.List;

public class OptsList {

	List<IPrintOpt> opts;

	public List<IPrintOpt> getList() {
		return opts;
	}

	public void setList(List<IPrintOpt> list) {
		this.opts = list;
	}

}
