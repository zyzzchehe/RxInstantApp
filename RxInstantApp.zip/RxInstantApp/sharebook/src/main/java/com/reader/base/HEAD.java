package com.reader.base;

public class HEAD {
	/**UHF mark to indicate the head of data package */
	public final static byte HEAD = (byte) 0xA0;
}
